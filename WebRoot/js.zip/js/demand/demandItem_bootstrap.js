

$(function(){
	$('#datatable1').dataTable( {
		"aoColumns": [
	      
	      null, null,null,null, null
		] } );

	//�����б�
	page(1);
	//��ʼ����
	$("#startDt").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#endDt").datepicker("option","minDate",dt);
		}
	});
	
	//��������
	$("#endDt").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#startDt").datepicker("option","maxDate",dt);
		}
	});
	

	
	//ɾ����ѵ��
	$("#btn_delete").click(function(){
		var ids = $("input:checkbox[name=groupTypeId]:checked");
		if(ids == null || ids == "" || ids.length == 0){
			alert("��ѡ��ɾ����");
		}
		else{
			if(confirm("ȷ��Ҫɾ��ѡ����")){
				var param = "method=remove&dtIds=";
				for(var i=0;i<ids.length;i++){
					param += $(ids[i]).val()+",";
				}
				$.ajax({
					url : basepath+"/demand/deleteItem.html",
					type : "POST",
					data : param,
					dataType : "JSON",
					success : function(data){
						if(data.code == 'error'){
							alert("�������ռ���������ѵ�������, �޷�ɾ��!");
						}
						page(1);
					},
					error:function(){
						alert("ɾ������!!!");
					}
				});
			}
		}
	});
	
});

/**
 * ��ҳ
 */
function page(i){
	var name = document.getElementById("dmdItemName").value;
	var status = $("input:radio[name=status]:checked").val();
	if(null==status){
		status="";
	}
	var max = $("#list_demandItem .page_max").val()?$("#list_demandItem .page_max").val():10;
	var isChildDep = $("input:radio[name=isChildDep]:checked").val();
	var dep_id = document.getElementById("dep_id").value;
	var startDt = document.getElementById("startDt").value;
	var endDt = document.getElementById("endDt").value;
	var value ="&name="+name+"&startDt="+startDt+"&endDt="+endDt+"&status="+status+"&dep_id="+dep_id+"&isChildDep="+isChildDep;
	var url = basepath+"/list/demandItemList.html?pagefn=page&page="+i+value+"&max="+max+"&r="+Math.random();
	$("#list_demandItem").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_demandItem .page_max").change(function(){
			page(1);
		});
	});
	
}
function orgClick(type,id,name){
	$("#dep_id").val(id);page(1);
}

function searchBottonClick(){
	var name = document.getElementById("classinput").value;
	if(name!=null){
		window.location = "demandItemIndex.html?name=" + name;
	}
}


