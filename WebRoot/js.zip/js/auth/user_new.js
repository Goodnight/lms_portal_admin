var treeType;
var sn_type = 0;//Ĭ���Զ�����
$(function(){
	
	 jQuery.validator.addMethod("phone", function(value, element) {
		   var tel=/^(^0\d{2}-?\d{8}$)|(^0\d{3}-?\d{7}$)|(^\(0\d{2}\)-?\d{8}$)|(^\(0\d{3}\)-?\d{7}$)$/;
		 
		  return this.optional(element) || (tel.test(value));
		  });
	 jQuery.validator.addMethod("alnum", function(value, element) {
		   var tel=/^[a-zA-Z0-9]+$/;
		 
		  return this.optional(element) || (tel.test(value));
		  });
	 

	
	$("#form_user").validate({
		errorPlacement: function(error, element) {
			var id = $(element).attr("id");
			error.appendTo( $("#"+id+"_error") );
		},
		rules : {
			sn : {
				required : true
			},
			name : {
				required : true,
				maxlength : 40
			},
			bir : {
				required : true,
				isDate : true
			},
			workDate : {
				required : true,
				isDate : true
			},
			mobile : {
				required : true,
				number : true,
				maxlength : 11
			},
			email : {
				required :true,
				email : true
			},
			certificateCode : {
				required :true,
				maxlength : 20,
				alnum:true
			},
			contact : {
				maxlength : 15,
				phone:true
			}
		},
		messages : {
			sn : "������Ա�����",
			name : {
				required : "������Ա������",
				maxlength : "������󳤶�Ϊ40���ַ�"
			},
			bir : {
				required : "�������������"
			},
			workDate : {
				required : "��������ְ����"
			},
			mobile : {
				required : "�������ֻ�����",
				number : "��������ȷ���ֻ�����",
				maxlength : "��������ȷ���ֻ�����"
			},
			email : {
				required : "������Email",
				email : "��������ȷ��Email��ʽ"
			},
			certificateCode : {
				required : "������֤�����",
				maxlength : "������볤��Ϊ20���ַ�",
				alnum:"ֻ���������ֺ���ĸ��"
			},
			contact : {
				maxlength : "������볤��Ϊ15���ַ�",
				phone:"��������ȷ�ĵ绰����"
					
			}
		}
		
	});
	
	$("#form_user").submit(function(){
		var re = true;
		var org_name = $("#org_name").val();
		var empNatureId = $("#empNatureId").val();
		var certificateTypeId = $("#certificateTypeId").val();
		var old_certificateCode = $("#old_certificateCode").val();
		var certificateCode = $("#certificateCode").val();
		var old_mobile = $("#old_mobile").val();
		var old_email = $("#old_email").val();
		var old_sn = $("#oldSn").val();
		var sn = $("#oriSn").val();
		var mobile = $("#mobile").val();
		var email = $("#email").val();
		var birth = $("#bir").val();
		if(sn_type==1){
			if(sn==null||sn==''){
				$('#sn_error').show();
				return false;
			}
		}else{
			if(old_sn==null||old_sn==''){//���ж����½�ʱ�����½�ʱold_snΪ�� SN�Զ����� 
				$("#oriSn").val('');
			}else{
				if(sn==null||sn==''){
					$('#sn_error').show();
					return false;
				}
			}
		}
		if(old_sn != sn){
			$.ajax({
				url : basepath+"/user/validate.html",
				type : "get",
				async : false,
				data : "type=sn&value="+sn,
				dataType : "json",
				success : function(data){
					//true���Ѿ�����
					re = !data;
				}
			});
		}		
		if(!re){
			$.dialog.alert("���˺��Ѿ�����!");
			return false;
		}
		
		if(old_email != email){
			$.ajax({
				url : basepath+"/user/validate.html",
				type : "get",
				async : false,
				data : "type=email&value="+email,
				dataType : "json",
				success : function(data){
					//true���Ѿ�����
					re = !data;
				}
			});
		}		
		if(!re){
			$.dialog.alert("Email�Ѿ�����!");
			return false;
		}
		
		if(old_mobile != mobile){
			$.ajax({
				url : basepath+"/user/validate.html",
				type : "get",
				async : false,
				data : "type=mobile&value="+mobile,
				dataType : "json",
				success : function(data){
					//true���Ѿ�����
					re = !data;
				}
			});
		}		
		if(!re){
			$.dialog.alert("Mobile�Ѿ�����!");
			return false;
		}
		
		//��֤֤������Ψһ
		if(old_certificateCode != certificateCode){
			$.ajax({
				url : basepath+"/user/validate.html",
				type : "get",
				async : false,
				data : "type=certificateCode&value="+certificateCode,
				dataType : "json",
				success : function(data){
					//true���Ѿ�����
					re = !data;
				}
			});
		}		
		if(!re){
			$.dialog.alert("֤�������Ѿ�����!");
			return false;
		}
		
		
		
		
		
		if(certificateTypeId == "usre_certificate_type_0"){
			$.dialog.alert("��ѡ��֤������");
			return false;
		}
		if(empNatureId == "user_empnature_0"){
			$.dialog.alert("��ѡ���ù�����");
			return false;
		}
		if(org_name==null ||org_name == ""){
			$.dialog.alert("��ѡ��Ա������");
			return false;
		}
		return re;
		
		
	});
	
	$("#certificateTypeId").change(function(){
		if($(this).find('option:selected').text() == "��ѡ��"){
			$("#certificateCode").val("");
			$("#certificateCode").attr("disabled",true);
		}else{
			$("#certificateCode").attr("disabled",false);
		}
	});
	
	//maxDate 16*365=5840 days
	$("#bir").datepicker({
	      	changeMonth: true,
	      	changeYear: true,
	      	showOn:"button",
			changeMonth: true,
			buttonImage:basepath+"/images/calendar.gif",
			buttonImageOnly:true,
			dateFormat:"yy-mm-dd",
			maxDate : "-5840d",
			yearRange:'-80',
			onSelect : function(dt){
				$("#workDate").datepicker("option","minDate",dt);
			}
	});
	
	$("#workDate").datepicker({
      	changeMonth: true,
      	changeYear: true,
      	showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		yearRange:'-64',
		dateFormat:"yy-mm-dd"
	});

	$(".newshowtree").click(function(){
		treeType = $(this).attr("id");
		var idpath = $("#idpath").val();
		var id = $("#org_id").val();
		var idpaths = idpath.substr(1,idpath.length);
		
		var idarry =idpaths.split("/");
		initTree("#user_jstree",id,idarry,treeType,function(type, id, name){
			if("pos" == type || "dep" == type){
				$("#"+treeType+"_id").val(id);
				$("#"+treeType+"_name").val(name);
			}
			if("org" == type){
				$("#"+treeType+"_id").val("");
				$("#"+treeType+"_name").val("");
			}
		});
	});

	$("#postLock").click(function(){
		var val = $(this).text();
		var uid = $(this).attr("uid");
		var lock = "";
		if(val == "������"){
			lock = "0";
		}else{
			lock = "1";
		}
		$.ajax({
			url : basepath+"/user/lockpost.html",
			type : 'post',
			data : 'uid='+uid+"&postLock="+lock,
			dataType : 'json',
			success : function(re){
				if(lock == "0"){
					$("#postLock").text("δ����");
				}else{
					$("#postLock").text("������");
				}
			},
			error : function(){}
		});
	});
	
	loadSecondCategory();
	$("#tech_category_upid").change(function(){
		loadSecondCategory();
	});	
});

/**
 * ���ؼ���ҵ���������б�
 */
function loadSecondCategory(){
	$("#second_tech_category").empty();
	$.ajax({
		url : basepath+"/user/getsecondcategory.html",
		type : "get",
		data : "upid="+$("#tech_category_upid").val(),
		dataType : "json",
		success : function(list){
			var choosed = $("#tech_category_id").val();
			for(i=0;i<list.length;i++){
				if(list[i].id == choosed){
					$("#second_tech_category").append("<option value='"+list[i].id+"' selected='selected'>"+list[i].name+"</option>");
				}else{
					$("#second_tech_category").append("<option value='"+list[i].id+"'>"+list[i].name+"</option>");
				}
			}
		}
	});	
}
/***����SN���ɺ��޸�ģ�� LuChao****/
function upSn(type){
	if(type==1){
		$('._sn').show();
		sn_type = 1;
	}else{
		$('._sn').hide();
		sn_type = 0;
	}
}




