
/**
* ������Ա�б�
*/
var user_id;
var flag; //����org 1��menu 0�ı��
$(function(){
	page(1);
	
	$("#rollco").focus(function(){
		var old = $(this).val();
		if(old == "�����ɫ����"){
			$(this).val("");
		}
	});
	
	$("#rollco").blur(function(){
		var old = $(this).val();
		if(old == ""){
			$(this).val("�����ɫ����");
		}
	});
	
	$("#searchButton").click(function(){
		page(1);
	});
	
	$("#clearFlush").click(function(){
		$("#authorizePerson_name").val("");
		$("#authorizePerson_id").val("");
	});
	
	$(".chooseperson").click(function(){
		var id = $(this).attr("id");
		var url = basepath+"/dialog/user.html?from=choose&html_name="+id+"_name&html_id="+id+"_id&r="+Math.random();
		$("#dialog_content").load(encodeURI(url));
		$("#dialog").show();
	});
	
	$(".cls_ok").live("click",function(){
		$(".blackall").hide();
	});
	
	//��ʼ����
	$("#startTimeId").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#endTimeId").datepicker("option","minDate",dt);
		}
	});
	
	//��������
	$("#endTimeId").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#startTimeId").datepicker("option","maxDate",dt);
		}
	});
						
	//Ȩ���Ƴ�
	$("#btn_delete").click(function(){
		var param = $.param($("input:checkbox[name=index]:checked"));
		if(param == null || param == ""){
			alert("��ѡ��ɾ����");
		}
		else{
			if(confirm("ȷ��Ҫɾ��ѡ����")){			
				$.ajax({
					url : "deleteStaff.html",
					type : "POST",
					data : param,
					dataType : "json",
					success : function(data){
						if(data == null){
							alert("ɾ������");
						}else{
							page(1);
						}
					},
					error:function(){
						alert("ɾ������");
					}
				});
			}
		}
	});	
	
	$(".adminshowtree").live("click",function(){
		var nowflag = $(this).attr("flag");
		flag = nowflag;
		if(flag==1){   //��Ϊ������ʱ			
			//////////////////////////////////
//			var operateuid = $(this).attr("id"); //��ҳ���ȡ��ǰ��¼�û���id
//			//alert("uid="+operateuid);
//			var rootId;
//			$.ajax({
//				  url : basepath+"/auth/adminshowtree.html",      //����ӿ� ����rootId
//				  type : "get",
//				  async: false,
//				  data : "operateuid="+operateuid,
//				  dataTye : "json",
//				  success : function(data){
//					  rootId = $.parseJSON(data.content);
//					  //alert("rootId="+rootId);
//				  },
//				  error:function(){
//					  alert("error");		
//				  }
//			});
			//////////////////////////////////ȡ��Ͻ��Χ���������ϼ� 20130401 LMSWD-2038@��÷����ȷ���޸� by LTC
			
			var uid = $(this).attr("id");
			var elements = $(".cls_"+uid);
			user_id = uid;
			var ids = new Array();
			var idpaths = new Array();
			for(i=0;i<elements.length;i++){
				var id = $(elements[i]).attr("orgid");
				ids.push(id);
				var idpath = $(elements[i]).attr("idpath").split("/");
				for(j=0;j<idpath.length;j++){
					if(idpath[j]!=id){
						idpaths.push(idpath[j]);
					}
				}
			}
			
			var url = basepath+"/list/org4jstree.html";
			$("#new_jstree_checkbox").jstree({
				"plugins":["themes","json_data","ui","types","checkbox"],
				"json_data":{
					"ajax" : {
						"url" : url,
						"cache":false,
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):0   //ȱʡ:���ڵ�id
							};
						}
					}
				},
				"types" : {
					"types" : {
						"pos" : {
							"valid_children" : "none",
							"icon" : {
								"image" : basepath+"/images/file.png"}
						},
						"dep" : {
							"valid_children" : "none",
							"icon" : {
								"image" : basepath+"/images/file.png"}
						}
					}
				},
				"ui":{
					"initially_select" : ids
				},
				"core":{
					"initially_open" : idpaths
				},
				"checkbox":{
					"two_state" : true,
					override_ui : true
				}
			});
		}
		if(flag==0){  //��Ϊ�˵���ʱ
			var uid = $(this).attr("id");
			var elements = $(".cls_"+uid);
			user_id = uid;
			var ids = new Array();
			var idpaths = new Array();
			for(i=0;i<elements.length;i++){
				var id = $(elements[i]).attr("mid");
				ids.push(id);
				var idpath = $(elements[i]).attr("idpath").split("/");
				for(j=0;j<idpath.length;j++){
					if(idpath[j]!=id){
						idpaths.push(idpath[j]);
					}
				}
			}
			initMenuCheckTree("#new_jstree_checkbox", ids, idpaths);
		}
	});
	
	//���ȷ��������ѡ��
	$(".treewindowsure").click(function(){
		if(flag==1){  //�������
			var param = "&user_id="+user_id;
			//�������ѡ�е�����
			$("#new_jstree_checkbox").jstree("get_selected").each(function(i,n){
				param += "&org_id="+n.id;
			});
			var url = basepath+"/auth/saveUserOrg.html";
			$.ajax({
				url: url,
				type : "post",
				data : param,
				dataType : "json",
				success : function(msg){
					page(1);
					$.dialog.tips("�����ɹ�",2,"tips.gif");
				},
				error : function(){
					$.dialog.tips("����ʧ��",2,"tips.gif");
				}
			});
		}
		if(flag==0){  //����˵�
			var param = "";
			//�������ѡ�е�����
			$("#new_jstree_checkbox").jstree("get_selected").each(function(i,n){
				param += "menu_ids="+n.id + "&";
			});
			if(param!=""){
				param += "&user_id="+user_id;
				var url = basepath+"/auth/saveUserMenu.html";
				$.ajax({
					url: url,
					type : "post",
					data : param,
					dataType : "json",
					success : function(msg){
						page(1);
						$.dialog.tips("�����ɹ�",2,"tips.gif");
					},
					error : function(){
						$.dialog.tips("����ʧ��",2,"tips.gif");
					}
				});
			}
		}
	});
});

var sign = "";
function orgClick(type,id,name){
	if(type=="dep"){
		sign = 1;
		$("#search_orgDepId").val(id);
		page(1);
		setNav(name);
	}
	else{
		sign = 0;
		$("#search_orgDepId").val(id);
		page(1);
		setNav(name);
	}
}

/**
 * ���µ���
 */
function setNav(name){
	$(".split").remove();
	$(".last").removeClass("last");
	$(".z ul").append("<li class='last split'>"+name+"</li>");
}

function page(i){
	$.dialog.tips('���ݼ�����...',600,'loading.gif');
	var query = "&ischilddep=0";
	var max = $("#list_managestafflist .page_max").val()?$("#list_managestafflist .page_max").val():10;
	var orgDepId = $("#search_orgDepId").val();
	if(orgDepId != null && orgDepId !=""){
		query += "&orgDepId="+orgDepId;
		query += "&sign="+sign;
	}
	else{
		var orgDepOriId = $("#orgDepOriId").val();
		query += "&orgDepId="+orgDepOriId;
		query += "&sign=0";
	}
	var roleId = $("#rollco").val();
	if(roleId != null && roleId != ""){
		if(roleId == "�����ɫ����"){
			roleId = "";
		}
		query += "&roleId="+roleId;
	}
	var sn = $("#snId").val();
	if(sn != null && sn != ""){
		query += "&sn="+sn;
	}
	var name = $("#nameId").val();
	if(name != null && name != ""){
		query += "&name="+name;
	}
	var authorizePerson = $("#authorizePerson_id").val();
	if(authorizePerson != null && authorizePerson != ""){
		query += "&authorizePerson="+authorizePerson;
	}
	var startTime = $("#startTimeId").val();
	if(startTime != null && startTime != ""){
		query += "&startTime="+startTime;
	}
	var endTime = $("#endTimeId").val();
	if(endTime != null && endTime != ""){
		query += "&endTime="+endTime;
	}

	var url = basepath+"/list/auth/manageStaffList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_managestafflist").load(encodeURI(url+query),function(){
		$.dialog.tips('���ݼ������',1,'tips.gif');
		ununiformedChooseAll("cls_chooseall");
		//ѡ��ÿҳ��¼����
		$("#list_managestafflist .page_max").change(function(){
			page(1);
		});
	});
}
