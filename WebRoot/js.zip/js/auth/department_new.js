
$(function(){
		$("#form_department").validate({
			rules : {
				sn : {
					required :true
				},
				name : {
					required :true
				},
				shortName : {
					required :true
				}
			},
			messages : {
				sn : "�����벿�ű��",
				name : "�����벿������",
				shortName : "�����벿�ż��"
			}
		});
		
		$(".cls_org_type").click(function(){
			if($(this).val()=="org"){
				var upid = $("#orgid").val();
				window.location.href = basepath+ "/organization/new.html?upid="+ upid;
			}
			if($(this).val()=="dep"){
				var orgid = $("#upid").val();
				window.location.href = basepath + "/department/new.html?orgid="+orgid+"&upid=0";
			}
		});
});
