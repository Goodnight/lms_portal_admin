
$(function(){
	$(".chooseperson").click(function(){
		var url = basepath+"/dialog/user.html?page=page&r="+Math.random();
		$("#dialog_content").load(url);
		$("#dialog").show();
	});
});