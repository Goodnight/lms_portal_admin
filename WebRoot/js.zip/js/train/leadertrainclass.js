
$(function(){
	page(1);
	//�߼�����
	$(".searchbutton").click(function(){
		page(1);
	});
	
	//��ѯ����
	$("#search_start_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_end_date").datepicker("option","minDate",dt);
		}
	});
	
	$("#search_end_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_start_date").datepicker("option","maxDate",dt);
		}
	});
	
});

/**
 * ��ҳ
 */
function page(i){
	$.dialog.tips('���ݼ�����...',600,'loading.gif');
	var max = $("#list_leadertrainclass .page_max").val()?$("#list_leadertrainclass .page_max").val():10;
	var name = $("#search_name").val();
	var start_date = $("#search_start_date").val();
	var end_date = $("#search_end_date").val();
	var query = "";
	if(name!=""&&name!="������ѵ�������"){
		query += "&name="+name;
	}
	if(start_date!=""){
		query+="&start_date="+start_date;
	}
	if(end_date!=""){
		query+="&end_date="+end_date;
	}
	var url = basepath+"/list/trainclass.html?from=leader&pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_leadertrainclass").load(encodeURI(url+query),function(){
		$.dialog.tips('���ݼ������',1,'tips.gif');
		$("#list_leadertrainclass .page_max").change(function(){
			page(1);
		});
	});
	
}



  

