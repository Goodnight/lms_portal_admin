jQuery.validator.addMethod("positiveinteger", function(value, element) {
		   var aint=parseInt(value);	
		    return aint>0&& (aint+"")==value;   
		  }, "Please enter a valid number."); 
$("#search_start_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_end_date").datepicker("option","minDate",dt);
		}
	});
	
	$("#search_end_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_start_date").datepicker("option","maxDate",dt);
		}
	});
$(function(){
	$("#form_scoreUserCost").validate({
		rules : {
			projectName : {
				required : true
			},
			begin_time : {
				required : true,
				isDate : true
			},
			end_time : {
				required : true,
				isDate : true
			},
			costScope_id : {
				required : true
			},
			score : {
				required : true,
				positiveinteger : true,
				0:true
			},
			costWay_id : {
				required : true
			}
		},
		messages : {
			projectName : "����Ϊ��",
			begin_time : "��ѡ��",
			end_time : "��ѡ��",
			costScope_id : "��Ϊ��",
			score : {
				required : "��Ϊ��",
				positiveinteger : "ֻ��Ϊ������!"
			},
			costWay_id : "��ѡ��"
			
			
		}
		
	});
});



$(function(){
	$("#form_scoreUserGain").validate({
		rules : {
			score : {
				required : true,
				number : true
			},
			gain_type_id : {
				required : true
			}
		},
		messages : {
			score : {
				required : "��Ϊ��",
				number : "ֻ��Ϊ����"
			},
			gain_type_id : "��ѡ��"
		}
		
	});
	
	//��ѡ����Ա�Ի���
	$(".chooseperson").click(function(){
		var id = $(this).attr("id");
		var url = basepath+"/dialog/user.html?from=choose&html_name="+id+"_name&html_id="+id+"_id&r="+Math.random();
		$("#dialog_content").load(encodeURI(url));
		$("#dialog").show();
	});
	
});
function change()
{
	var costScope_id=$("#costScope_id option:checked").val();
	//alert(costScope_id);
	if(costScope_id=="402882f03879c326013879c6a3bd0003")
		{
			document.getElementById("score").readOnly = true;
			document.getElementById("score").value=0;
		}
	else
		{
			document.getElementById("score").readOnly = false;
			document.getElementById("score").value="";
		}
}

//��֤����һ�������С��ʣ�������
$(document).ready(function(){
	$("input[name='_next']").on("click",function(){
		var costScope = $("#costScope_id option:checked").text();
		var score = $("#score").val();
		var dmScore = $("#dmscore").text();
		var psScore = $("#psscore").text();
		if(costScope == "ʹ�ò��Ż���"){
			if(score - dmScore > 0){
				alert("�һ��Ĳ��Ż��ֲ��ܴ���ʣ�ಿ�Ż��֣�");
				return false;
			}
		}
		if(costScope == "ʹ�ø��˻���"){
			if(score - psScore > 0){
				alert("�һ��ĸ��˻��ֲ��ܴ���ʣ����˻��֣�");
				return false;
			}
		}
	});
});
