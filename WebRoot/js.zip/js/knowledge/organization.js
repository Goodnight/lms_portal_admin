
$(function(){
	//��ת��ҳʱ����֪ʶ����������
	var idarry =  idpath.split("/");
	
	var idarrys=idarry;
	if(idarry==""||idarry==null){
		idarrys=0;
	}
	$("#kno_jjjstree").jstree({
		"plugins":["themes","json_data","types","ui"],
		"json_data":{
			"ajax" : {
				"url" : basepath+"/knowledge/knowledge4jstree.html",
				"cache":false,
				"data" : function(n){
					return {
						"operation":"",
						"id":n.attr?n.attr("id"):"root_0",
								"name":n.attr?n.attr("name"):0,
										"namePath":n.attr?n.attr("name"):0,
												"idPath":n.attr?n.attr("idPath"):0
					};
				}
			}
		},
		"types" : {
			
				"kno" : {
					"valid_children" : "none",
					"icon" : {
						"image" : basepath+"/images/file.png"}
				}
			
		},
		"ui":{
			"initially_select":idarry
		},
		"core":{
			"initially_open":idarrys
		}
	}).bind("select_node.jstree",function(e,data){
		var id = data.rslt.obj.attr("id");
		var type = data.rslt.obj.attr("type");
		var name = data.rslt.obj.attr("name");
		var namePath = data.rslt.obj.attr("namePath");
		var idPath = data.rslt.obj.attr("idPath");
		orgClick(type,id);
	});
	
});



/**
 * ֪ʶ����������¼�
 */
function orgClick(type,id){
	var url = "";
	if(type=="kno"){
		url = basepath+"/knowledge/detail.html?kcId="+id+"&r="+Math.random();
	}
	
	//����ƶ�ʱ
	$("#detail_org").load(encodeURI(url),function(){
		$(".choosedepartment").click(function(){ 
			var x=$(this).offset().left;
			var y=$(this).offset().top;
			$(".moveKnoledge").css("left",x);
			$(".moveKnoledge").css("top",y);
			$(".moveKnoledge").css("position","absolute");
			$(".moveKnoledge").css("z-index","9999");
			$(".moveKnoledge").show();
			
			$("#moveChoosed").jstree({
				/*
				"plugins":["themes","json_data","ui"],
				"json_data":{
					"ajax" : {
						"url" : basepath+"/knowledge/knowledge4jstree.html",
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):0
							};
						}
					}
				}
				*/
				"plugins":["themes","json_data","types","ui","core"],
				"json_data":{
					"ajax" : {
						"url" : basepath+"/knowledge/knowledge4jstree.html",
						"cache":false,
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):"root_0",
										"name":n.attr?n.attr("name"):0,
												"namePath":n.attr?n.attr("name"):0,
														"idPath":n.attr?n.attr("idPath"):0
														
							};
						}
					}
				},
				"types" : {
					
						"kno" : {
							"valid_children" : "none",
							"icon" : {
								"image" : basepath+"/images/file.png"}
						}
					
				},
				"core":{
					"initially_open":knoRootId  //Ĭ��չ�����ڵ��µ��ӽڵ�.
				}
			}).bind("select_node.jstree",function(e,data){
				var id = data.rslt.obj.attr("id");
				var type = data.rslt.obj.attr("type");
				knowledgeClick(type,id,name);
			});
		 });
		
		$(".moveKnoledge a").click(function(){
			$(".moveKnoledge").hide();							  
		});
		
		//�������ѡ��֪ʶ����Ĵ��
		$(".chooseMove").click(function(){
			$(".blackall").show();
			$("#move").show();
		});
		$("#closeMove").click(function(){
			$(".blackall").hide();
			$("#move").hide();	
			$(".leftKno").hide();
			$(".rightKno").hide();
		});
		
		//����������ѡ��֪ʶ�����
		$(".moveTeam").click(function(){
		 	var x=$(this).offset().left;
			var y=$(this).offset().top;
			$(".leftKno").css("left",x);
			$(".leftKno").css("top",y);
			$(".leftKno").css("position","absolute");
			$(".leftKno").css("z-index","9999");
			$(".leftKno").show();
			$(".moveTeamChoosede").jstree({
				/*
				"plugins":["themes","json_data","ui"],
				"json_data":{
					"ajax" : {
						"url" : basepath+"/knowledge/knowledge4jstree.html",
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):0
							};
						}
					}
				}
				*/
				"plugins":["themes","json_data","types","ui","core"],
				"json_data":{
					"ajax" : {
						"url" : basepath+"/knowledge/knowledge4jstree.html",
						"cache":false,
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):"root_0",
										"name":n.attr?n.attr("name"):0,
												"namePath":n.attr?n.attr("name"):0,
														"idPath":n.attr?n.attr("idPath"):0
														
							};
						}
					}
				},
				"types" : {
					
						"kno" : {
							"valid_children" : "none",
							"icon" : {
								"image" : basepath+"/images/file.png"}
						}
					
				},
				"core":{
					"initially_open":knoRootId  //Ĭ��չ�����ڵ��µ��ӽڵ�.
				}
			}).bind("select_node.jstree",function(e,data){
				var id = data.rslt.obj.attr("id");
				var name = data.rslt.obj.attr("name");
				var type = data.rslt.obj.attr("type");
				add(type,id,name);
			});

			
		 });
		$(".leftKno a").click(function(){
			$(".leftKno").hide();							  
		});
		
		
		//��������ұ�ѡ��֪ʶ�����
		$(".moveTeamToRightMove").click(function(){
		 	var x=$(this).offset().left;
			var y=$(this).offset().top;
			$(".rightKno").css("left",x);
			$(".rightKno").css("top",y);
			$(".rightKno").css("position","absolute");
			$(".rightKno").css("z-index","9999");
			$(".rightKno").show();
			$(".rightToMoveForKnoledge").jstree({
				/*
				"plugins":["themes","json_data","ui"],
				"json_data":{
					"ajax" : {
						"url" : basepath+"/knowledge/knowledge4jstree.html",
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):0
							};
						}
					}
				}
				*/
				"plugins":["themes","json_data","types","ui","core"],
				"json_data":{
					"ajax" : {
						"url" : basepath+"/knowledge/knowledge4jstree.html",
						"cache":false,
						"data" : function(n){
							return {
								"operation":"",
								"id":n.attr?n.attr("id"):"root_0",
										"name":n.attr?n.attr("name"):0,
												"namePath":n.attr?n.attr("name"):0,
														"idPath":n.attr?n.attr("idPath"):0
														
							};
						}
					}
				},
				"types" : {
					
						"kno" : {
							"valid_children" : "none",
							"icon" : {
								"image" : basepath+"/images/file.png"}
						}
					
				},
				"core":{
					"initially_open":knoRootId  //Ĭ��չ�����ڵ��µ��ӽڵ�.
				}
			}).bind("select_node.jstree",function(e,data){
				var id = data.rslt.obj.attr("id");
				var name = data.rslt.obj.attr("name");
				var type = data.rslt.obj.attr("type");
				addToRight(type,id,name);
				
			});

			
		 });
		$(".rightKno a").click(function(){
			$(".rightKno").hide();							  
		});
		
	});
	
}


/**
 * ѡ�е�֪ʶ�������ӵ�����б���
 */
function add(type,id,name){
	var newTr = "<tr><td><input type='a' class='removebutton' id='"+id+"' name='choosedKnowledge' onclick='remove(this)'/></td>"
						+"<input type='hidden' name='kcIdOne' value='"+id+"'/>"
						+"<td>"+name+"</td>"
                        +"</td></tr>";
	$("#choosedKnowledge").append($(newTr));

}


/**
 * ѡ�е�֪ʶ�������ӵ��ұ��б���
 */
function addToRight(type,id,name){
	$("#choosedKnowledgeToRight").html("");
	
	var newTr = "<tr><td><input type='button' class='removebutton' id='"+id+"' name='choosedKnowledgeToRight' onclick='remove(this)'/></td>"
						+"<input type='hidden' name='kcIdTwo' value='"+id+"'/>"
						+"<td>"+name+"</td>"
                        +"</td></tr>";
	$("#choosedKnowledgeToRight").append($(newTr));

}

//�Ƴ�ѡ��õ�֪ʶ����
function remove(obj){
	var cbList = $("input:checkbox[name=cId]:checked");
	for(i=0;i<cbList.length;i++){
		var cb = cbList[i];
		if($(cb).val()==$(obj).attr("id")){
			$(cb).attr("checked",false);
			$(cb).attr("disabled",false);
		}
	}
	$(obj).parent().parent().remove();
	$.uniform.update();
}



/**
 * ֪ʶ�����ƶ���
 */
function knowledgeClick(type,id,name){
	var kcId = $("#kcId").val();
	var url = "";
	if(type=="kno"){
		url = basepath+"/knowledge/move.html";
	}
	if(confirm('ȷ��Ҫ�ƶ��� ��')){
	$.ajax({
		url : url,
		type : "post",
		data : "kcId="+kcId+"&upId="+id,
		dataType : "json",
		success : function(re){
			alert("ok");
			window.location.reload();
			orgClick(type,id);
		}
	});
	}
	$(".moveKnoledge").hide();
}



/**
 * ֪ʶ���������ƶ�
 */
$("#btn_moveTeam").click(function(){
	var left = $.param($("input[name=kcIdOne]"));
	var right = $.param($("input[name=kcIdTwo]"));
	var url = basepath+"/knowledge/moveTeamForKnowledge.html";
	if(confirm('ȷ��Ҫ�ƶ��� ��')){
	$.ajax({
		url : url,
		type : "post",
		data : left+"&"+right,
		dataType : "json",
		success : function(re){
			alert("ok");
			window.location.reload();
		}
	});
	}
	$(".leftKno").hide();
	$(".rightKno").hide();
});


//�����Ƴ�
function deleteAbility(id){
var param = id;
if(confirm('ȷ��Ҫɾ���� ��')){
$.ajax({
	url : "delete.html?kcId="+id,
	type : "POST",
	data : param,
	dataType : "json",
	success : function(data){
		if(data == null){
			alert("����ѡ��һ��");
		}
		else if(data.code == 'success'){
		    alert("ɾ���ɹ�!");
			window.location.reload();	
		} else {
			alert("ɾ��ʧ��!");
		}
	}
});
}
}


//��ת�޸ı�ǩ����
function toUpdateKnowledge(id){
	var url = basepath+"/knowledge/toUpdate.html?kcId="+id+"&r="+Math.random();
	$("#dialog_content").load(encodeURI(url));
	$("#dialog").show();
}


//�ر��޸Ļ�������ǩ����
function closedUpdateWindow(){
	$(".blackall").hide();
	$("#dialog_content").children().remove();
	$("#dialog").hide();
	}

//��ת������ǩ����
function toAddKnowledge(id){
	var url = basepath+"/knowledge/toAddKnowledge.html?kcId="+id+"&r="+Math.random();
	$("#dialog_content").load(encodeURI(url));
	$("#dialog").show();
}


//����ѡ���ǩ��
function selectTag(id){
	var url = basepath+"/knowledge/toSelectTag.html?kcId="+id;
	$("#selectTag").load(encodeURI(url));
	$(".blackall").hide();
	$("#windowtree2").show();
}

//�رձ�ǩ��
function closed(){
	$(".blackall").hide();
	$("#dialog_content").children().remove();
	}



//ɾ��֪ʶ�����µı�ǩ
function deleteTag(id,tId){
	if(confirm('ȷ��Ҫɾ���� ��')){
		if (id == null || id == "" || tId == null || tId == "") {
			$.dialog.alert("��ѡ��ɾ���");
		} else {
			$.ajax({
				url : basepath + "/knowledge/deleteTag.html",
				type : "POST",
				data : "kcId="+id+"&tagId="+tId,
				dataType : "json",
				success : function(data){
					alert("OK");
					window.location.reload();
				}
			});
		}
	}
}


