
/**
 * ��ҳ
 */
setOrgData(0);
$(function(){
	page(1);
	
	$("#searchButton").click(function(){
		page(1);
	});
	
	$("#page_max").change(function(){
		page(1);
	});
	
	/**
	* ɾ��������Ա����
	*/

	$("#deleteStaff").click(function(){
			if(confirm("ȷ��Ҫɾ��ѡ����")){
				var ids = $("input:checkbox[name=staffIndex]:checked");
				var param = "method=remove&maId=";
				if(ids.length>0){
					for(n=0;n<ids.length;n++){
						param += $(ids[n]).val()+",";
					}
					$.ajax({
						url : basepath+"/meetingManage/deleteStaff.html",
						type : "POST",
						data : param,
						dataType : "json",
						success : function(data){
							if(data!=null){
								page(1);
							}else{
								alert("�Ƴ�����");
							}
						},
						error : function(){
							alert("�Ƴ�����");
						}
					});
				}
			}		
	});
	
	//��ѡ����Ա�Ի���
	$("#selectStaff").click(function(){
		var url = basepath+"/dialog/user.html?page=page&r="+Math.random();
		$("#dialog_content").load(url);
		$("#dialog,#dialog .blackall,#dialog .newwindow").show();
	});
	
	$(".cls_ok").click(function(){
		alert("haha");
	});
});

function page(i){
	var query = "";
	var max = $("#list_mtstafflist .page_max").val()?$("#list_mtstafflist .page_max").val():10;
	var page_mId = $("#page_mId").val();
	if(page_mId != null && page_mId != ""){
		query += "&page_mId="+page_mId;
	}
	var staffSn = document.getElementById("snId").value;
	if(staffSn != null && staffSn != ""){
		query += "&sn="+staffSn;
	}
	var staffName = document.getElementById("nameId").value;
	if(staffName != null && staffName != ""){
		query += "&name="+staffName;
	}
	var url = basepath+"/list/meetingManage/meetingStaffList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_mtstafflist").load(encodeURI(url+query),function(){
		$.dialog.tips('���ݼ������',1,'tips.gif');
		bindChooseAll("cls_chooseall");
		//ѡ��ÿҳ��¼����
		$("#list_mtstafflist .page_max").change(function(){
			page(1);
		});
	});
}

