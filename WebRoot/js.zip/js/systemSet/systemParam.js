$(function(){
	page(1);
	
	$("#searchButton").click(function(){
		page(1);
	});
	
	//����ϵͳ��������
	$("#newParam").click(function(){
		var url = basepath+"/dialog/createSysParam.html";
		$("#dialog_content").load(url);
		$("#dialog").show();
	});
	
	//ɾ��ϵͳ����
	$("#btn_delete").click(function(){
		var param = $.param($("input:checkbox[name=index]:checked"));
		if(param == null || param == ""){
			alert("��ѡ��ɾ����");
		}
		else{
			if(confirm("ȷ��Ҫɾ��ѡ����")){	
				$.ajax({
					url : basepath+"/systemParam/deleteSystemParam.html",
					type : "POST",
					data : param,
					dataType : "json",
					success : function(data){
						if(data == null){
							alert("ɾ������");
						}else{
							page(1);
						}
					},
					error:function(){
						alert("ɾ������");
					}
				});
			}
		}
	});
});

function page(i){
	$.dialog.tips('���ݼ�����...',600,'loading.gif');
	var query = "&ischilddep=0";
	var max = $("#list_paramList .page_max").val()?$("#list_paramList .page_max").val():25;
	var param_Name = $("#param_Name").val();
	if(param_Name != null && param_Name != ""){
		query += "&param_Name="+param_Name;
	}
	var param_Type = $("#param_Type").val();
	if(param_Type != null && param_Type != ""){
		query += "&param_Type="+param_Type;
	}
	var url = basepath+"/list/systemParam/systemParamList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_paramList").load(encodeURI(url+query),function(){
		$.dialog.tips('���ݼ������',1,'tips.gif');
		bindChooseAll("cls_chooseall");
		//ѡ��ÿҳ��¼����
		$("#list_paramList .page_max").change(function(){
			page(1);
		});
	});
}
