
setPosData(0);
$(function(){
	//�����б�
	page(1);
	
	$("#name").focus(function(){
		var ms=$(this).val();
		if(ms=="�����ĵ�����"){
			$(this).val("");		
		}						   
	});
	$("#name").blur(function(){
		var ms=$(this).val();
		if(ms==""){
			$(this).val("�����ĵ�����");		
		}
	});
	
	//��ѯ����
	$("#search_start_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_end_date").datepicker("option","minDate",dt);
		}
	});
	
	$("#search_end_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_start_date").datepicker("option","maxDate",dt);
		}
	});
	
});

//�����ı�״̬
$(".forsetup").live("click", function(){
	$(this).hide();
	$(this).next().show();
})
$(".select_setup img").live("click", function(t,id){
	
	t = $(this).prev().val();
	id = $(this).attr("id");
	var url = basepath +"/doc/updateDoc.html";
	var param = "dId="+id+"&status="+t;
	if(confirm('ȷ��Ҫ�ı䷢��״̬�� ��')){
	$.ajax({
		url : url,
		type : "post",
		data : param,
		dataType : "json",
		success : function(msg){
			
		},
		error : function(){}
	});
	var mm=$(this).prev().val();
	if(mm == 0)
	{
		mm = "δ����";
	}
	if(mm == 1)
	{
		mm = "�ѷ���";
	}
	if(mm == 2)
	{
		mm = "���ύ";
	}
	if(mm == 3)
	{
		mm = "ʡ����׼";
	}
	$(this).parent().prev().text(mm);
	$(this).parent().hide();
	$(this).parent().prev().show();
	}
	
})
	
	//���Ӿ�����Դ
	$("#btn_jh").click(function(){
		var param = $.param($("input:checkbox[name=groupTypeId]:checked"));
		if(confirm('ȷ��Ҫ����Ϊ��Ʒ��Դ�� ��')){
		$.ajax({
			url : "doSaveDocRes.html",
			type : "POST",
			data : param,
			dataType : "json",
			success : function(data){
				alert("OK");
				page(1);					
			}
		}
		);
		}
	});
	
	//������ʷ��Դ
	$("#btn_ls").click(function(){
		var param = $.param($("input:checkbox[name=groupTypeId]:checked"));
		if(confirm('ȷ��Ҫ����Ϊ��ʷ��Դ�� ��')){
		$.ajax({
			url : "doSaveDocByLs.html",
			type : "POST",
			data : param,
			dataType : "json",
			success : function(data){
				alert("OK");
				page(1);					
			}
		}
		);
		}
	});
	
	
	

function searchBottonClick(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var query = "";
	var name = $("#name").val();
	if(name == "�����ĵ�����")
	{
	name = "";
	}
	query += "&name="+name;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_trainclass").load(encodeURI(url+query),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			searchBottonClick(1);
		});
	});
}


//����ɾ��
$("#btn_delete").click(function(){
	var param = $.param($("input:checkbox[name=groupTypeId]:checked"));
	if(confirm('ȷ��Ҫɾ���� ��')){
	$.ajax({
		url : "deleteDocPic.html",
		type : "POST",
		data : param,
		dataType : "json",
		success : function(data){
			    alert("OK");
				window.location.reload();					
			
		}
	});
	}
});




/**
 * ����������¼�
 */
/**
 * ����������¼�
 */
var orgId;
var knoId;
function orgClick(type,id,name){
			resetSearch();
		    if(type == "" || type == null)
		    {
			orgId = "";
			knoId = "";
		    }
		    if(type == "org")
		    {
			orgId = id;
			knoId = "";
			
		    }
		    if(type == "kno")
		    {
			orgId = "";
			knoId = id;
		    }
      //����¼�
		    	$.ajax({
		    		url : "toShowAllOrg.html?orgId="+id,
		    		type : "get",
		    		dataType : "json",
		    		success : function(namepath){
		    			setNav(namepath);
		    			selectBottonClick(1);
		    		}
		    	});
}

/**
 * ���µ���
 */
function setNav(name){
	$(".split").remove();
	$(".last").removeClass("last");
	$(".z ul").append("<li class='last split'>"+name+"</li>");
}



//�߼�����
function selectBottonClick(i){
	$.dialog.tips('���ݼ�����...',600,'loading.gif');
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var query = "";
	if(orgId!=""){
		query += "&orgId=" + orgId;
	}
	
	if(knoId!=""){
		query += "&knoId=" + knoId;
	}
	
	var positionIds = "";
	if(return_data.length>0 && return_data[0]!=null && return_data[0].length>0){
		positionIds = return_data[0][0]["id"];
	}
	
	if(positionIds!=""){
		query += "&positionIds=" + positionIds;
	}
	
	var name = $("#name").val();
	if(name == "�����ĵ�����")
	{
	name = "";
	}
	query += "&name="+name;
	var sn = $("#sn").val();
	query += "&sn="+sn;
	var startTime = $("#search_start_date").val();
	query += "&startTimet="+startTime;
	var endTime = $("#search_end_date").val();
	query += "&endTime="+endTime;
	var tag = $("#tag").val();
	query += "&tag="+tag;
	var suit = $("#suits").val();
	query += "&suit="+suit;
	var status = $("#status").val();
	if(status == "��ѡ��")
		{
		status = "";
		}
	query += "&status="+status;
	
	var isChildOrg = $("input:radio[name=isSub]:checked")[0].value;
	query+="&isChildOrg="+isChildOrg;
	
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_trainclass").load(encodeURI(url+query),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$.dialog.tips('���ݼ������',1,'tips.gif');
		$("#list_trainclass .page_max").change(function(){
			selectBottonClick(1);
		});
	});
}


//���������γ�
function seachJHClick(i,obj){
	var jh = $(obj).attr("id");
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random()+"&elite="+jh;
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			seachJHClick(1,this);
		});
	});
}



//ȫѡ��ѡ
function checkAll(formvalue) {  
    var roomids = document.getElementsByName(formvalue);  
    for (var j = 0; j < roomids.length; j++) {  
        if (roomids.item(j).checked == false) {  
            roomids.item(j).checked = true;
            
        }  
        else{
        	roomids.item(j).checked = false; 
        }
    }
    $.uniform.update();
}  



/**
 * ��ҳ
 */
function page(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			page(1);
		});
	});
	
}

//����
function ll(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random() + "&order=stat.view";
	
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			ll(1);
		});
	});
}

function xz(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random() + "&order=stat.download";
	
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			xz(1);
		});
	});
}

function fx(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random() + "&order=stat.share";
	
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			fx(1);
		});
	});
}

function pl(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random() + "&order=stat.comment";
	
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			pl(1);
		});
	});
}

function zg(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random() + "&order=createDt" + "&sort=desc";
	
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			zg(1);
		});
	});
}

function zd(i){
	var max = $("#list_trainclass .page_max").val()?$("#list_trainclass .page_max").val():10;
	var url = basepath+"/list/toDocPicList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random() + "&order=createDt" + "&sort=Asc";
	
	$("#list_trainclass").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_trainclass .page_max").change(function(){
			zd(1);
		});
	});
}


//�����ǩ�ı���ʽ
$("#pX a").click(function(){
	$(this).siblings().removeClass("selected");
	$(this).addClass("selected");
})

$("#gZ a").click(function(){
	$(this).siblings().removeClass("selected");
	$(this).addClass("selected");
})

$("#nR a").click(function(){
	$(this).siblings().removeClass("selected");
	$(this).addClass("selected");
})


/**
 * ���ò�ѯ����
 */
function resetSearch(){
	$("#search_dep_id").val("");
	$("#name").val("");
	$("#sn").val("");
	$("#startTime").val("");
	$("#endTime").val("");
	$("#tag").val("");
	$("#suits").val("");
	$("#status").val("");
}
