$(function(){
	//�����б�
	
	//��ѯ����
	$("#search_start_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_end_date").datepicker("option","minDate",dt);
		}
	});
	
	$("#search_end_date").datepicker({
		showOn:"button",
		changeMonth: true,
		buttonImage:basepath+"/images/calendar.gif",
		buttonImageOnly:true,
		dateFormat:"yy-mm-dd",
		onSelect : function(dt){
			$("#search_start_date").datepicker("option","maxDate",dt);
		}
	});
	
});


//Ԥ��
function clickshpw(obj)
{
   outCode = $(obj).attr("title"); 
   $.ajax({
 		url : basepath+"/courseware/toLookCourse.html?outCote="+outCode,
 		type : "POST",
 		data : outCode,
 		dataType : "json",
 		success : function(status){
 			if (status == "2" || status == "3") {
 				alert("��Դ���ڽ�ѹ�������Ժ�Ԥ��!");
 			}
 			if(status != "2" && status != "3" && status != "4" && status != "" && status != null)
 			{
 			alert("���Ų��ɹ�");
 			}
 			if(status == "4" || status == "" || status == null)
 			{
 			id = $(obj).attr("id");
 			window.open(id,"ctu_player","channelmode=yes,fullscreen=yes,location=no,menubar=no,toolbar=no,titlebar=no");
 			}
 		}
 	});
	}



//ȫѡ��ѡ
function checkAll(formvalue) {  
    var roomids = document.getElementsByName(formvalue);  
    for (var j = 0; j < roomids.length; j++) {  
        if (roomids.item(j).checked == false) {  
            roomids.item(j).checked = true;
            
        }  
        else{
        	roomids.item(j).checked = false; 
        }
    }  
    $.uniform.update();
}  

/**
 * ��ҳ
 */
function page(i){
	//��ҳ���ø߼������Ĳ�ѯ����.
	selectBottonClick(i);
	/*
	var max = $("#list_libraryResList .page_max").val()?$("#list_libraryResList .page_max").val():10;
	var url = basepath+"/list/toLibraryResList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_libraryResList").load(encodeURI(url),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$(".cls_checkbox").uniform();
		$("#list_libraryResList .page_max").change(function(){
			page(1);
		});
	});
	*/
}

//�߼�����
function selectBottonClick(i){
	$.dialog.tips('���ݼ�����...',600,'loading.gif');
	var max = $("#list_libraryResList .page_max").val()?$("#list_libraryResList .page_max").val():10;
	var query = "";
	if(orgId!="" && orgId!= null){
		query += "&orgId=" + orgId;
	}
	
	if(knoId!="" && knoId!= null){
		query += "&knoId=" + knoId;
	}
	var name = $("#name").val();
	query += "&name="+name;
	var sn = $("#sn").val();
	query += "&rlId="+sn;
	var type = $("#type").val();
	query += "&type="+type;
	var startDt = $("#search_start_date").val();
	query += "&startDt="+startDt;
	var endDt = $("#search_end_date").val();
	query += "&endDt="+endDt;
	var orgName = $("#orgName").val();
	query += "&orgName="+orgName;
	var isChildOrg = $("input:radio[name=isSub]:checked")[0].value;
	query+="&isChildOrg="+isChildOrg;
	var isChildKno = $("input:radio[name=isSubs]:checked")[0].value;
	query += "&isChildKnowledge=" + isChildKno;
	var url = basepath+"/list/toLibraryResList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_libraryResList").load(encodeURI(url+query),function(){
		$(".cls_chooseall").click(function(){
			if($(this).attr("checked")){
				$(".cls_chooseitem").attr("checked",true);
			}else{
				$(".cls_chooseitem").attr("checked",false);
			}
			$.uniform.update();
		});
		$.dialog.tips('���ݼ������',1,'tips.gif');
		$(".cls_checkbox").uniform();
		$("#list_libraryResList .page_max").change(function(){
			selectBottonClick(1);
		});
	});
}


function export_list(){
	var query = "&elite=1";
	if(orgId!="" && orgId!= null){
		query += "&orgId=" + orgId;
	}
	if(knoId!="" && knoId!= null){
		query += "&knoId=" + knoId;
	}
	var name = $("#name").val();
	query += "&name="+name;
	var sn = $("#sn").val();
	query += "&sn="+sn;
	var type = $("#type").val();
	query += "&type="+type;
	var startDt = $("#search_start_date").val();
	query += "&startDt="+startDt;
	var endDt = $("#search_end_date").val();
	query += "&endDt="+endDt;
	
	loadingDataStart();
	var countUrl = basepath + "/trainresource/exportCount.html?r="+Math.random();
	var listUrl = basepath + "/trainresource/exportList.html?r="+Math.random();
	postData(encodeURI(countUrl+query),encodeURI(listUrl+query));
}


//�����Ƴ�
$("#btn_delete").click(function(){
	var param = $.param($("input:checkbox[name=groupTypeId]:checked"));
	if(param == null || param.length == 0)
	{
		$.dialog.alert("��ѡ���Ƴ��");
		return;
	}
	
	if(confirm('ȷ��Ҫ�Ƴ���Ʒ��Դ���� ��')){
		if(param == null)
		{
			$.dialog.alert("��ѡ��ɾ���");
		}
		else{
	$.ajax({
		url : "deleteLibraryRes.html",
		type : "POST",
		data : param,
		dataType : "json",
		success : function(data){
			if(data == null){
				alert("����ѡ��һ��");
			}
			else{
			    alert("OK");
			    selectBottonClick(1);
			}
			
		}
	});
		}
	}
});


//����ɾ��
$("#btn_deleteAll").click(function(){
	var param = $.param($("input:checkbox[name=groupTypeId]:checked"));
	
	if(param == null || param.length == 0)
	{
		$.dialog.alert("��ѡ��ɾ���");
		return;
	}
	
	if(confirm('ȷ��Ҫɾ����Դ�� ��')){
		if(param == null)
		{
			$.dialog.alert("��ѡ��ɾ���");
		}
		else{
	$.ajax({
		url : "deleteAllLibraryRes.html",
		type : "POST",
		data : param,
		dataType : "json",
		success : function(data){
			if(data == null){
				alert("����ѡ��һ��");
			}
			else{
			    alert("OK");
			    selectBottonClick(1);	
			}
		}
	});
		}
	}
});


/**
 * ����������¼�
 */
var orgId;
var knoId;
function orgClick(type,id,idPath,name,namePath){
	if(type == "" || type == null)
    {
	orgId = "";
	knoId = "";
    }
    if(type == "org")
    {
	orgId = id;
	if(knoId != null && knoId != "" && knoId != "undefined")
	{
	knoId = knoId;
	}
	setNav(name);
	selectBottonClick(1);
    }	    			
}


$("#kno_jjjstree").jstree({
	"plugins":["themes","json_data","types","ui"],
	"json_data":{
		"ajax" : {
			"url" : basepath+"/knowledge/knowledge4jstree.html",
			"cache":false,
			"data" : function(n){
				return {
					"operation":"",
					"id":n.attr?n.attr("id"):"root_0",
							"name":n.attr?n.attr("name"):0,
									"namePath":n.attr?n.attr("name"):0,
											"idPath":n.attr?n.attr("idPath"):0
											
				};
			}
		}
	},
	"types" : {
		
			"kno" : {
				"valid_children" : "none",
				"icon" : {
					"image" : basepath+"/images/file.png"}
			}
		
	},
	"core":{
		"initially_open":knoRootId
	}
}).bind("select_node.jstree",function(e,data){
	var id = data.rslt.obj.attr("id");
	var type = data.rslt.obj.attr("type");
	var name = data.rslt.obj.attr("name");
	var namePath = data.rslt.obj.attr("namePath");
	var idPath = data.rslt.obj.attr("idPath");
	knoClick(type,id,idPath,name,namePath);
});


function knoClick(type,id,idPath,name,namePath){
    if(type == "" || type == null)
    {
	orgId = "";
	knoId = "";
    }
    if(type == "kno")
    {
    	if(orgId != null && orgId != "")
		{
    		orgId = orgId;
		}
	knoId = id;
	setNav(name);
	selectBottonClick(1);
    }
}



/**
 * ���µ���
 */
function setNav(name){
	$(".split").remove();
	$(".last").removeClass("last");
	$(".z ul").append("<li class='last split'>"+name+"</li>");
}
