$(function(){
	page(1);
	
	$("#searchButton").click(function(){
		page(1);
	});
	
	//����֪ʶ��
	$("#newKnowledgePoint").click(function(){
		if (knoId == undefined || knoId == '0' || knoId == '') {
			alert("��ѡ��֪ʶ����!");
			return;
		}
		
		var url = basepath+"/dialog/createKnowledgePoint.html?knoId="+knoId;
		$("#dialog_content").load(url);
		$("#dialog").show();
	});
	
	//ɾ��֪ʶ��
	$("#btn_delete").click(function(){
		var param = $.param($("input:checkbox[name=index]:checked"));
		if(param == null || param == "" || param.length == 0)
		{
			$.dialog.alert("��ѡ��ɾ���");
			return;
		}
		if(confirm("ȷ��Ҫɾ��ѡ����")){
			$.ajax({
				url : basepath+"/knowledgePoint/deleteKnowledgePoint.html",
				type : "POST",
				data : param,
				dataType : "json",
				success : function(data){
					if(data == null){
						alert("ɾ��ʧ�ܣ�����ɾ����֪ʶ��!");
					}else{
						page(1);
					}
				},
				error:function(){
					$.dialog.alert("��ѡ��ɾ���");
				}
			});
		} 
	});
});

//��ҳ
function export_knowledgepoint(){
	
	var query = "";
	if(orgId!=""){
		query += "&orgId=" + orgId;
	}
	
	if(knoId !="" || knoId !=null){
		query += "&knoId=" + knoId;
	}
	var isChildOrg = $("input:radio[name=isSub]:checked")[0].value;
	query+="&isChildOrg="+isChildOrg;
	var name = $("#name").val();
	if(name != "")
	{
		query += "&name=" + name;
	}
	loadingDataStart();
	var countUrl = basepath + "/knowledgePoint/exportCount.html?r="+Math.random();
	var listUrl = basepath + "/knowledgePoint/exportList.html?r="+Math.random();
	postData(encodeURI(countUrl+query),encodeURI(listUrl+query));
	
}

//��ҳ
function page(i){
	$.dialog.tips('���ݼ�����...',600,'loading.gif');
	$("#kId").attr("value","");
	var query = "";
	var max = $("#list_knowledgepointlist.page_max").val()?$("#list_knowledgepointlist.page_max").val():10;
	if(orgId!=""){
		query += "&orgId=" + orgId;
	}
	
	if(knoId !="" || knoId !=null){
		query += "&knoId=" + knoId;
	}
	var isChildOrg = $("input:radio[name=isSub]:checked")[0].value;
	query+="&isChildOrg="+isChildOrg;
	var isChildKno = $("input:radio[name=isSubs]:checked")[0].value;
	query += "&isChildKnowledge=" + isChildKno;
	var name = $("#name").val();
	if(name != "")
	{
		query += "&name=" + name;
	}
	var url = basepath+"/list/knowledgePoint/knowledgePointList.html?pagefn=page&page="+i+"&max="+max+"&r="+Math.random();
	$("#list_knowledgepointlist").load(encodeURI(url+query),function(){
		$.dialog.tips('���ݼ������',1,'tips.gif');
		bindChooseAll("cls_chooseall");
		//ѡ��ÿҳ��¼����
		$("#list_knowledgepointlist.page_max").change(function(){
			page(1);
		}); 
	});
}

//����������¼�
var orgId;
var knoId;
function orgClick(type,id,name,namePath){
		    if(type == "" || type == null)
		    {
			orgId = "";
			knoId = "";
		    }
		    if(type == "org")
		    {
			orgId = id;
			knoId = "";	
 			$("#newKnowledgePoint").css("display","none");
	    			setNav(name);
	    		    page(1);
		    }
		    if(type == "kno")
		    {
				    $("#newKnowledgePoint").attr("display","block"); 
					$("#newKnowledgePoint").show(); 
			orgId = "";
			if(name == "���з���")
			{
				knoId = "";
			}
			else{
			knoId = id;
			}
			setNav(namePath);
		    page(1);
		   
		    }
		    	
}

/**
 * ���µ���
 */
function setNav(namePath){
	$(".split").remove();
	$(".last").removeClass("last");
	$(".z ul").append("<li class='last split'>"+namePath+"</li>");
}
